<template>
	<h1>Addgoods</h1>
</template>