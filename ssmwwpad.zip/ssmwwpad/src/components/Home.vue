<template>
		<div class="col-md-12">
			<div id="testid" class="carousel slide" data-ride="carousel">
			  <ol class="carousel-indicators">
			    <li data-target="#testid" data-slide-to="0" class="active"></li>
			    <li data-target="#testid" data-slide-to="1"></li>
			    <li data-target="#testid" data-slide-to="2"></li>
					<!--
			    <li data-target="#testid" data-slide-to="3"></li>
			    <li data-target="#testid" data-slide-to="4"></li>
					-->
			  </ol>

			  <div class="carousel-inner">
			    <div class="carousel-item active">
			      <img class="d-block w-100" 
			      src="wwpadstatic/img/b.jpg" 
			      alt="First slide">
			    </div>
			    <div class="carousel-item">
			      <img class="d-block w-100" 
			      src="wwpadstatic/img/a.jpg" 
			      alt="Second slide">
			    </div>
			    <div class="carousel-item">
			      <img class="d-block w-100" 
			      src="wwpadstatic/img/c.jpg" 
			      alt="Third slide">
			    </div>
					<!-- 
			    <div class="carousel-item">
			      <img class="d-block w-100" 
			      src="http://p1.meituan.net/codeman/826a5ed09dab49af658c34624d75491861404.jpg" 
			      alt="Four slide">
			    </div>
			    <div class="carousel-item">
			      <img class="d-block w-100" 
			      src="http://p0.meituan.net/codeman/daa73310c9e57454dc97f0146640fd9f69772.jpg"
			      alt="Five slide">
			    </div>
					 -->
			  </div>
				<!-- 上一页 -->
			  <a class="carousel-control-prev" href="#testid" role="button" data-slide="prev">
			    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
			    <span class="sr-only">Previous</span>
			  </a>
				<!-- 下一页 -->
			  <a class="carousel-control-next" href="#testid" role="button" data-slide="next">
			    <span class="carousel-control-next-icon" aria-hidden="true"></span>
			    <span class="sr-only">Next</span>
			  </a>
			</div>
		</div>


</template>

<!-- 


http://p0.meituan.net/codeman/33ff80dc00f832d697f3e20fc030799560495.jpg
http://p1.meituan.net/codeman/bb0abb3435a60c44d87e90ed4237b61039329.jpg
http://p0.meituan.net/codeman/a97baf515235f4c5a2b1323a741e577185048.jpg
http://p1.meituan.net/codeman/826a5ed09dab49af658c34624d75491861404.jpg
http://p0.meituan.net/codeman/daa73310c9e57454dc97f0146640fd9f69772.jpg


 -->